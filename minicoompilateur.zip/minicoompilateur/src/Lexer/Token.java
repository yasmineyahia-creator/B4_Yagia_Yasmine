package lexer;

public class Token {
    public enum TokenType {
        MOT_CLE, MOT_CLE_PERSONNALISE, IDENTIFIANT, NOMBRE, OPERATEUR, SEPARATEUR, INVALIDE, FIN
    }

    private final TokenType type;
    private final String valeur;

    public Token(TokenType type, String valeur) {
        this.type = type;
        this.valeur = valeur;
    }

    public TokenType getType() {
        return type;
    }

    public String getValeur() {
        return valeur;


}

    @Override
    public String toString() {
        return "<" + type + ", \"" + valeur + "\">";
    }
}






