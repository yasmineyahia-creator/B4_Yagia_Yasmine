package lexer;

import java.util.ArrayList;
import java.util.List;

public class Lexer {
    private final String texte;
    private int index = 0;
    private final List<Token> tokens = new ArrayList<>();
    private final SymboleTable symbolTable = new SymboleTable();

    public Lexer(String texte) {
        this.texte = texte;
    }

    private boolean estLettre(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private boolean estChiffre(char c) {
        return Character.isDigit(c);
    }

    private boolean estOperateur(char c) {
        return "+-*/=!<>&|%".indexOf(c) != -1;
    }

    private boolean estSeparateur(char c) {
        return ";,(){}[].".indexOf(c) != -1;
    }

    public List<Token> tokenize() {
        while (index < texte.length()) {
            char c = texte.charAt(index);

            if (Character.isWhitespace(c)) { index++; continue; }

            if (estLettre(c)) {
                StringBuilder sb = new StringBuilder();
                sb.append(c);
                index++;
                while (index < texte.length() && (estLettre(texte.charAt(index)) || estChiffre(texte.charAt(index)))) {
                    sb.append(texte.charAt(index));
                    index++;
                }
                String lex = sb.toString();
                Token.TokenType type = symbolTable.getType(lex);
                tokens.add(new Token(type, lex));
                continue;
            }

            if (estChiffre(c)) {
                StringBuilder sb = new StringBuilder();
                sb.append(c);
                index++;
                while (index < texte.length() && estChiffre(texte.charAt(index))) {
                    sb.append(texte.charAt(index));
                    index++;
                }
                tokens.add(new Token(Token.TokenType.NOMBRE, sb.toString()));
                continue;
            }

            if (estOperateur(c)) {
                // Vérifier les opérateurs à deux caractères
                String op2 = (index + 1 < texte.length()) ? "" + c + texte.charAt(index + 1) : "";
                if (symbolTable.getType(op2) == Token.TokenType.OPERATEUR) {
                    tokens.add(new Token(Token.TokenType.OPERATEUR, op2));
                    index += 2;
                    continue;
                } else {
                    tokens.add(new Token(Token.TokenType.OPERATEUR, "" + c));
                    index++;
                    continue;
                }
            }

            if (estSeparateur(c)) {
                tokens.add(new Token(Token.TokenType.SEPARATEUR, "" + c));
                index++;
                continue;
            }

            tokens.add(new Token(Token.TokenType.INVALIDE, "" + c));
            index++;
        }

        tokens.add(new Token(Token.TokenType.FIN, "#"));
        return tokens;
    }

    public void printTokens() {
        tokens.forEach(System.out::println);
    }
}
