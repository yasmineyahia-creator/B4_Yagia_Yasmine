package lexer;

import java.util.HashMap;
import java.util.Map;

public class SymboleTable {
    private final Map<String, Token.TokenType> table;

    public SymboleTable() {
        table = new HashMap<>();

        // Mots-clés Java
        String[] motsCles = {
            "int","double","float","String","char","boolean",
            "if","else","while","for","do","switch","case",
            "break","continue","return","public","private","protected",
            "static","final","class","void","new","try","catch"
        };
        for (String mc : motsCles) table.put(mc, Token.TokenType.MOT_CLE);

        // Mot-clé personnalisé
        table.put("yasmineyahia", Token.TokenType.MOT_CLE_PERSONNALISE);

        // Opérateurs
        String[] operateurs = {"+","-","*","/","=","==","!=","<",">","<=",">=","&&","||","%","++","--","+=","-=","*=","/="};
        for (String op : operateurs) table.put(op, Token.TokenType.OPERATEUR);

        // Séparateurs
        String[] separateurs = {";",",","(",")","{","}","[","]","."};
        for (String sep : separateurs) table.put(sep, Token.TokenType.SEPARATEUR);
    }

    public Token.TokenType getType(String lexeme) {
        return table.getOrDefault(lexeme, Token.TokenType.IDENTIFIANT);
    }
}
