package parse;

import lexer.Token;
import java.util.List;
import java.util.Stack;

public class Parser {

    private final List<Token> tokens;
    private int index = 0;
    private boolean erreur = false;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    private Token courant() {
        if (index < tokens.size()) return tokens.get(index);
        return new Token(Token.TokenType.FIN, "#");
    }

    private void avancer() { index++; }

    private void parseExpression() {
        try {
            Token t = courant();

            // Expression doit commencer par un identifiant, nombre ou mot-clé personnalisé
            if (t.getType() != Token.TokenType.IDENTIFIANT &&
                t.getType() != Token.TokenType.NOMBRE &&
                t.getType() != Token.TokenType.MOT_CLE_PERSONNALISE) {
                System.out.println("Erreur syntaxique : expression doit commencer par un identifiant, nombre ou mot-clé personnalisé, trouvé '" + t.getValeur() + "'");
                erreur = true;
                avancer();
                return;
            }

            avancer();

            // Vérifie toute la suite d'opérateurs et valeurs
            while (courant().getType() == Token.TokenType.OPERATEUR) {
                avancer();
                t = courant();
                if (t.getType() != Token.TokenType.IDENTIFIANT &&
                    t.getType() != Token.TokenType.NOMBRE &&
                    t.getType() != Token.TokenType.MOT_CLE_PERSONNALISE) {
                    System.out.println("Erreur syntaxique : opérateur suivi d'une valeur attendue, trouvé '" + t.getValeur() + "'");
                    erreur = true;
                    avancer();
                    return;
                }
                avancer();
            }

            // Vérifie le point-virgule
            if (courant().getType() != Token.TokenType.SEPARATEUR || !courant().getValeur().equals(";")) {
                System.out.println("Erreur syntaxique : point-virgule manquant à la fin de l'expression");
                erreur = true;
            } else {
                avancer();
            }

        } catch (Exception e) {
            System.out.println("Erreur syntaxique : " + e.getMessage());
            erreur = true;
        }
    }

    public void parse() {
        System.out.println("=== Analyse syntaxique ===");
        Stack<String> parentheseStack = new Stack<>();
        erreur = false;

        while (index < tokens.size()) {
            Token t = courant();
            try {
                switch (t.getType()) {

                    case IDENTIFIANT, MOT_CLE_PERSONNALISE, NOMBRE:
                        parseExpression();
                        break;

                    case SEPARATEUR:
                        if (t.getValeur().equals("(")) parentheseStack.push("(");
                        else if (t.getValeur().equals(")")) {
                            if (parentheseStack.isEmpty()) {
                                System.out.println("Erreur syntaxique : parenthèse fermante sans ouvrante");
                                erreur = true;
                            } else parentheseStack.pop();
                        }
                        avancer();
                        break;

                    case OPERATEUR:
                        System.out.println("Erreur syntaxique : opérateur isolé '" + t.getValeur() + "'");
                        erreur = true;
                        avancer();
                        break;

                    case INVALIDE:
                        System.out.println("Erreur syntaxique : caractère invalide '" + t.getValeur() + "'");
                        erreur = true;
                        avancer();
                        break;

                    case FIN:
                        avancer();
                        break;

                    default:
                        avancer();
                        break;
                }
            } catch (Exception e) {
                System.out.println("Erreur syntaxique : " + e.getMessage());
                erreur = true;
                avancer();
            }
        }

        if (!parentheseStack.isEmpty()) {
            System.out.println("Erreur syntaxique : parenthèse(s) ouvrante(s) non fermée(s)");
            erreur = true;
        }

        if (!erreur) System.out.println("Analyse syntaxique terminée : aucune erreur détectée !");
        else System.out.println("Analyse syntaxique terminée avec des erreurs.");
    }
}
