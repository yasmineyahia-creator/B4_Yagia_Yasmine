package parse;

import lexer.Lexer;
import lexer.Token;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean continuer = true;

        while (continuer) {
            System.out.println("=== Mini-Compilateur Java ===");
            System.out.println("1 : Tester l'analyse lexicale");
            System.out.println("2 : Tester l'analyse syntaxique");
            System.out.println("q : Quitter");
            System.out.print("Votre choix : ");
            String choix = sc.nextLine().trim();

            try {
                if (choix.equals("1")) {
                    System.out.println("Entrez votre code ligne par ligne. Entrez une ligne vide pour terminer :");
                    StringBuilder code = new StringBuilder();
                    while (true) {
                        String ligne = sc.nextLine();
                        if (ligne.isEmpty()) break;
                        code.append(ligne).append("\n");
                    }
                    Lexer lexer = new Lexer(code.toString());
                    List<Token> tokens = lexer.tokenize();
                    System.out.println("\n--- Lexèmes générés ---");
                    lexer.printTokens();

                } else if (choix.equals("2")) {
                    System.out.println("Entrez votre code ligne par ligne. Entrez une ligne vide pour terminer :");
                    StringBuilder code = new StringBuilder();
                    while (true) {
                        String ligne = sc.nextLine();
                        if (ligne.isEmpty()) break;
                        code.append(ligne).append("\n");
                    }
                    Lexer lexer = new Lexer(code.toString());
                    List<Token> tokens = lexer.tokenize();
                    System.out.println("\n--- Lexèmes générés ---");
                    lexer.printTokens();

                    Parser parser = new Parser(tokens);
                    parser.parse();

                } else if (choix.equalsIgnoreCase("q")) {
                    continuer = false;
                    System.out.println("Fin du programme !");
                } else {
                    throw new Exception("Choix invalide !");
                }
            } catch (Exception e) {
                System.out.println("Erreur : " + e.getMessage());
            }

            System.out.println("\n--------------------------------------------------\n");
        }

        sc.close();
    }
}
